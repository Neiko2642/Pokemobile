Pokemobile is still a work in progress game nothing special.

v1 - Rough fundamentals 'cli' version of pokemon 
v2 - Refined fundamentals 'cli' version of pokemon
v3 - html css js using the canvas of pokemon
v4 - will be adding in mysql database to store all the info and for user progress 

By : Neiko2642